//Somut Ürün2
public class Clothing implements Product{
    public void displayDetails(){
        System.out.println("Giyim ürün detayları.");
    }
}
