// Konu arayüzü
public interface ProductObservable {
    void addObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}
