// Arabulucu Arayüzü
public interface Mediator {
    void notify(Component sender, String event);
}