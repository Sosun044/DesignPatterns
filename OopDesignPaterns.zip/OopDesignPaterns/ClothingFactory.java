//Somut yaratıcı
public class ClothingFactory extends ProductFactory {
    public Product createProduct() {
        return new Clothing();
    }
}