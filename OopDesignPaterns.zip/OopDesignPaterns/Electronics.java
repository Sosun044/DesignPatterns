//Somut Ürün 1
public class Electronics implements Product{
    public void displayDetails(){
        System.out.println("Elektronik ürün detayları.");
    }
}
