public class OrderManager extends Component {
    public OrderManager(Mediator mediator) {
        super(mediator);
    }
    public void processOrder() {
        System.out.println("Sipariş işlendi.");
    }
}