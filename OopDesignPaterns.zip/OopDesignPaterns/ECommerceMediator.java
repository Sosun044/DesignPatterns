// Somut Arabulucu
public class ECommerceMediator implements Mediator {
    private ProductManager productManager;
    private UserManager userManager;
    private OrderManager orderManager;
    
    public void setProductManager(ProductManager productManager) {
        this.productManager = productManager;
    }
    
    public void setUserManager(UserManager userManager) {
        this.userManager = userManager;
    }
    
    public void setOrderManager(OrderManager orderManager) {
        this.orderManager = orderManager;
    }
    
    public void notify(Component sender, String event) {
        if (event.equals("orderPlaced")) {
            orderManager.processOrder();
        } else if (event.equals("productUpdated")) {
            userManager.notifyUsers();
        }
    }
}
