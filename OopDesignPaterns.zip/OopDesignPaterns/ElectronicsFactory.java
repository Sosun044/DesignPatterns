//Somut yaratıcı
public class ElectronicsFactory extends ProductFactory{
    public Product createProduct(){
        return new Electronics();
    }
}
