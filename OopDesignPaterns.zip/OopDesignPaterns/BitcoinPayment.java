public class BitcoinPayment implements PaymentStrategy {
    public void pay(double amount) {
        System.out.println(amount + " Bitcoin ile ödendi.");
    }
}