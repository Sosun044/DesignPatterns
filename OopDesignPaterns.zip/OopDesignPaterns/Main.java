public class Main {
    public static void main(String[] args) {
        
        ProductFactory factory = new ElectronicsFactory();
        Product product = factory.createProduct();
        product.displayDetails(); // Çıktı: Elektronik ürün detayları.
        
        factory = new ClothingFactory();
        product = factory.createProduct();
        product.displayDetails(); // Çıktı: Giyim ürün detayları.
        
        /*
        Product product = new Product();
        
        User user1 = new User("Kullanıcı 1");
        User user2 = new User("Kullanıcı 2");
        
        product.registerObserver(user1);
        product.registerObserver(user2);
        
        product.setInStock(true); // Çıktı: Kullanıcı 1: Ürün stoğu güncellendi. Kullanıcı 2: Ürün stoğu güncellendi.
     */
    /*
    PaymentManager paymentManager = new PaymentManager();

        // Kredi kartı ile ödeme
        PaymentStrategy creditCardPayment = new CreditCardPaymentStrategy("1234-5678-9876-5432", "John Doe", "12/25", "123");
        paymentManager.setPaymentStrategy(creditCardPayment);
        paymentManager.pay(250.0); // Çıktı: 250.0 TL kredi kartı ile ödendi. Kart: 1234-5678-9876-5432

        // PayPal ile ödeme
        PaymentStrategy payPalPayment = new PayPalPaymentStrategy("john@example.com", "password123");
        paymentManager.setPaymentStrategy(payPalPayment);
        paymentManager.pay(150.0); // Çıktı: 150.0 TL PayPal ile ödendi. Email: john@example.com

        // Kapıda ödeme
        PaymentStrategy cashOnDeliveryPayment = new CashOnDeliveryPaymentStrategy();
        paymentManager.setPaymentStrategy(cashOnDeliveryPayment);
        paymentManager.pay(100.0); // Çıktı: 100.0 TL kapıda ödeme ile ödendi.
    */
    /*
     ECommerceMediator mediator = new ECommerceMediator();

        ProductManager productManager = new ProductManager(mediator);
        UserManager userManager = new UserManager(mediator);
        OrderManager orderManager = new OrderManager(mediator);

        mediator.setProductManager(productManager);
        mediator.setUserManager(userManager);
        mediator.setOrderManager(orderManager);

        productManager.updateProduct(); // Çıktı: Ürün güncellendi. Kullanıcılar ürün güncellemesi hakkında bilgilendirildi. 
     */
    }
    
}
