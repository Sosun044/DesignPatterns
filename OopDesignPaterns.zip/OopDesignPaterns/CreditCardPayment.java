// Somut Stratejiler
public class CreditCardPayment implements PaymentStrategy {
    public void pay(double amount) {
        System.out.println(amount + " kredi kartı ile ödendi.");
    }
}