// Somut Bileşenler
public class ProductManager extends Component {
    public ProductManager(Mediator mediator) {
        super(mediator);
    }
    
    public void updateProduct() {
        System.out.println("Ürün güncellendi.");
        mediator.notify(this, "productUpdated");
    }
}