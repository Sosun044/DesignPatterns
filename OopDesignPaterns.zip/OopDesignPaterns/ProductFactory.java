// Yaratıcı
public abstract class ProductFactory{
    public abstract Product createProduct();
}
