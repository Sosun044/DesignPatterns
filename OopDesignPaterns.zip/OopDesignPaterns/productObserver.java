import java.util.ArrayList;
import java.util.List;

public class productObserver implements ProductObservable{
    private List<Observer> observers = new ArrayList<>();
    private String name;
    private int stock;

    public productObserver(String name,int stock){
        this.name = name;
        this.stock = stock; 
    }
    
    public void setStock(int stock) {
        this.stock = stock;
    }
    
    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    public void notifyObservers(){
        for(Observer observer : observers){
            observer.update(name + "Stogu güncellendi: " + stock);
        }

    }

}

    

    
    
    

