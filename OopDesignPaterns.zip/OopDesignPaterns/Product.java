public interface Product {
    void displayDetails();
}
