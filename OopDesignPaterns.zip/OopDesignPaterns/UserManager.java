public class UserManager extends Component {
    public UserManager(Mediator mediator) {
        super(mediator);
    }
    
    public void notifyUsers() {
        System.out.println("Kullanıcılar ürün güncellemesi hakkında bilgilendirildi.");
    }
}